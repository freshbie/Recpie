from django.contrib import admin
from django.utils.safestring import mark_safe
from .models import RecipeCategory,RecipePost,RecipeComment
from django.utils.safestring import mark_safe
class RecipeCategoryAdmin(admin.ModelAdmin):
    list_display = ['title']

class RecipePostAdmin(admin.ModelAdmin):
    list_display = ['title','category','image']
    readonly_fields = ["recipe_image",]

    def recipe_image(self, obj):
        return mark_safe('<img src="{url}" width="{width}" height={height} />'.format(
            url = obj.image.url,
            width=obj.image.width,
            height=obj.image.height,
            )
    )

class RecipeCommentAdmin(admin.ModelAdmin):
    list_display = ['recipe','author','comment','created_date']

admin.site.register(RecipeCategory,RecipeCategoryAdmin)
admin.site.register(RecipePost,RecipePostAdmin)
admin.site.register(RecipeComment,RecipeCommentAdmin)
