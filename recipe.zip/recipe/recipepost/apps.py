from django.apps import AppConfig


class RecipepostConfig(AppConfig):
    name = 'recipepost'
