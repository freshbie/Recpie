from django.db import models
import datetime
from django.conf import settings

class RecipeCategory(models.Model):
    title=models.CharField(max_length=50)

    def __str__(self):
        return self.title

class RecipePost(models.Model):
    category=models.ForeignKey(RecipeCategory,on_delete=models.CASCADE)
    title=models.CharField(max_length=50)
    image = models.ImageField(upload_to='recipe_imgs/', blank=True)
    description=models.TextField()

    def __str__(self):
        return self.title
        

class RecipeComment(models.Model):
    now = datetime.datetime.now()
    recipe=models.ForeignKey(RecipePost,on_delete=models.CASCADE)
    author=models.EmailField(max_length=254)
    comment=models.TextField()
    created_date=models.DateTimeField(now,null=True,blank=True)
    approved_comment=models.BooleanField(default=False)

    def __approve__(self):
        self.approved_comment=True
        self.save()

    def __str__(self):
        return self.recipe.title
