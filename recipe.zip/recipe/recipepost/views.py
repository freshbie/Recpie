from django.shortcuts import render
from django.http import HttpResponse
import datetime
from .models import RecipePost,RecipeComment

# Create your views here.
def home(request):
    search_string=request.GET.get('q','')
    recipes=RecipePost.objects.filter(title__contains=search_string)
    return render(request,'home.html',{'recipes':recipes})

def detail(request,id):
    recipeDetail=RecipePost.objects.get(pk=id)
    recipeComments=RecipeComment.objects.filter(recipe=id)
    if request.method=="POST":
        now = datetime.datetime.now()
        comment=RecipeComment()
        comment.recipe=recipeDetail
        comment.created_date=now
        comment.author=request.POST.get('author_email')
        comment.comment=request.POST.get('comment')
        comment.save()
    return render(request,'detail.html',{'recipeDetail':recipeDetail,'recipeComments':recipeComments})
    